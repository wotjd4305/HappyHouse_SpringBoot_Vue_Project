export default class memberinfo {
    constructor(id, pass, name, address, phonenum) {
      this.id = id;
      this.pass = pass;
      this.name = name;
      this.address = address;
      this.phonenum = phonenum;
    }
}
<template>
 <div class="dummy">
     <br>
 </div>
</template>

<script>
export default {

}
</script>
   
<style>
 .dummy{
        margin: 30%;
    }
</style>
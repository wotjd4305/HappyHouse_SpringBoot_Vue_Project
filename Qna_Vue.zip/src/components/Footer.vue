<template>
<div>
  <body>
<!-- Footer -->
<!--<br>
<br>-->
<footer class="footer_1">
  <p>Powered by <a href="https://www.w3schools.com/w3css/default.asp" title="W3.CSS" target="_blank" class="w3-hover-text-green">HappyHouse</a></p>
</footer>

</body>
</div>
</template>

<script>
export default {

}
</script>

<style>
	.footer_1 {
        
    position: relative;
    bottom: 0px;
    width: 100%;
   padding: 15px 0;
   text-align: center;
   color: white;
   background-color: #333;
   }



</style>
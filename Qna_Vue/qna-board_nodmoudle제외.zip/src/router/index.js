import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'
import QnaList from '@/components/QnaList.vue'
import QnaWrite from '@/components/QnaWrite.vue'
import QnaRead from '@/components/QnaRead.vue'
import QnaModify from '@/components/QnaModify.vue'

Vue.use(VueRouter)
export default new VueRouter({
  mode: "history",
  routes:[
    {
      path: '/',
      name: 'Home',
      component: Home
    },
    {
      path: '/qnalist',
      name: 'QnaList',
      component: QnaList
    },
    {
      path: '/qnawrite',
      name: 'QnaWrite',
      component: QnaWrite
    },
    {
      path: '/qnaread/:no',
      name: 'QnaRead',
      component: QnaRead
    },
    {
      path: '/qnamodify/:no',
      name: 'QnaModify',
      component: QnaModify
    },
    {
      path: '/about',
      name: 'About',
      // route level code-splitting
      // this generates a separate chunk (about.[hash].js) for this route
      // which is lazy-loaded when the route is visited.
      component: () => import(/* webpackChunkName: "about" */ '../views/About.vue')
    }
]
});
